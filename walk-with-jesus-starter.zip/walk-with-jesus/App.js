import React, { useMemo, useState } from "react";
import {
  SafeAreaView, ScrollView, View, Text, TextInput, Pressable,
  StyleSheet, StatusBar, KeyboardAvoidingView, Platform
} from "react-native";

const topics = [
  { label: "Forgiveness", prompt: "I'm having trouble forgiving someone who hurt me." },
  { label: "Worry & anxiety", prompt: "I feel anxious about the future and don't know what to do." },
  { label: "Relationships", prompt: "I'm struggling in a relationship and want to respond with love and wisdom." },
  { label: "Guilt & renewal", prompt: "I made a mistake and feel ashamed. How can I move forward?" },
  { label: "Loneliness", prompt: "I feel lonely and wonder whether anyone really cares about me." },
  { label: "Grief & loss", prompt: "I'm grieving a loss and struggling to find comfort." },
  { label: "Hard decisions", prompt: "I'm facing a difficult decision and need wisdom." },
  { label: "Purpose", prompt: "I feel stuck and want to find purpose and direction." },
];

function makeGuidance(input) {
  const s = input.toLowerCase();
  let scripture = "“Be quick to listen, slow to speak and slow to become angry.” — James 1:19. This passage encourages a pause before reacting and invites us to respond thoughtfully rather than impulsively.";
  let practice = "Give yourself room to breathe before deciding what to do. Name what you are feeling, consider what is within your control, and choose one response that reflects honesty, compassion, and wisdom. A trusted, fair-minded person may help you see the situation more clearly.";
  const prayer = "Jesus, meet me in what I am carrying. Help me see this situation with honesty and compassion. Give me courage to take the next wise step, patience where I need it, and support when I cannot manage it alone. Amen.";

  if (/forgiv|betray|hurt|anger|mad/.test(s)) {
    scripture = "“Be kind and compassionate to one another, forgiving each other, just as in Christ God forgave you.” — Ephesians 4:32. Scripture makes room for mercy, truth, accountability, and wise boundaries.";
    practice = "You do not have to pretend the hurt did not happen or restore trust immediately. Consider what you need to be safe, whether an honest conversation is possible, and what forgiveness might look like one step at a time. Forgiveness does not require accepting ongoing harm.";
  } else if (/anx|worr|future|fear|stress/.test(s)) {
    scripture = "“Do not worry about tomorrow, for tomorrow will worry about itself.” — Matthew 6:34. Jesus invites his listeners to trust God and attend to the present day rather than be consumed by what might happen.";
    practice = "Write down what is worrying you. Separate what you can act on today from what is outside your control, then choose one manageable step. Seeking practical help from someone you trust can be an expression of wisdom, not a lack of faith.";
  } else if (/shame|mistake|guilt|failed|sin/.test(s)) {
    scripture = "See Luke 15:11–24, the parable of the lost son, for a picture of welcome, repentance, and restoration. Jesus meets people with compassion and an invitation to move toward a better path.";
    practice = "Acknowledge what happened without reducing your whole identity to one mistake. If you harmed someone, consider a sincere apology and appropriate repair. Give yourself permission to learn, accept support, and take the next honest step.";
  } else if (/lonely|loneliness|alone|left out|isolat/.test(s)) {
    scripture = "“I am with you always, to the very end of the age.” — Matthew 28:20. Scripture offers comfort and also reminds us that people need community and care.";
    practice = "Consider one small connection today: message someone safe, attend a community gathering, or tell a trusted person honestly that you have been feeling alone. Reaching out is a brave step, not a burden.";
  } else if (/grief|grieving|loss|died|death|mourning/.test(s)) {
    scripture = "“Blessed are those who mourn, for they will be comforted.” — Matthew 5:4. Jesus does not dismiss grief; John 11:35 shows him weeping at Lazarus’ tomb.";
    practice = "You do not need to rush your grief or find a lesson in it today. Let someone trustworthy sit with you, keep one gentle routine if you can, and seek grief support if the weight feels too heavy to carry alone.";
  } else if (/decision|choose|choice|direction|purpose|calling/.test(s)) {
    scripture = "“If any of you lacks wisdom, you should ask God, who gives generously to all.” — James 1:5. Scripture encourages prayer, humility, and wise counsel rather than rushed certainty.";
    practice = "Write down your options, the values that matter most, and who could offer wise and honest counsel. Pray for clarity, check likely consequences, and choose the next responsible step rather than expecting to see the whole road at once.";
  } else if (/conflict|argument|fight|disagree|relationship|marriage|family/.test(s)) {
    scripture = "“Blessed are the peacemakers.” — Matthew 5:9. Jesus calls people toward peace and truth; making peace does not mean ignoring harm or staying in an unsafe situation.";
    practice = "When it is safe, pause until you can speak calmly, describe the issue without insults, and listen to the other person's perspective. Set clear boundaries where needed. If there is abuse or danger, prioritize safety and reach out to trusted support.";
  }

  return { scripture, practice, prayer };
}

export default function App() {
  const [problem, setProblem] = useState("");
  const [guidance, setGuidance] = useState(null);
  const [error, setError] = useState("");
  const characterCount = useMemo(() => problem.length, [problem]);

  function explore() {
    if (!problem.trim()) {
      setError("Write a little about what you are facing, or choose a topic above.");
      return;
    }
    setError("");
    setGuidance(makeGuidance(problem.trim()));
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      <KeyboardAvoidingView style={styles.safe} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <View style={styles.logo}><Text style={styles.logoText}>✦</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.brand}>Walk With Jesus</Text>
              <Text style={styles.tagline}>SCRIPTURE FOR REAL LIFE</Text>
            </View>
            <View style={styles.badge}><Text style={styles.badgeText}>BETA</Text></View>
          </View>

          <View style={styles.hero}>
            <Text style={styles.kicker}>A quiet place to begin</Text>
            <Text style={styles.title}>What's weighing{"\n"}on your heart?</Text>
            <Text style={styles.intro}>Bring your questions, struggles, and decisions. Explore biblical wisdom and consider one gentle next step.</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Share what's going on</Text>
            <Text style={styles.muted}>You don't have to find the perfect words. Start wherever you are.</Text>
            <TextInput
              value={problem}
              onChangeText={(v) => { setProblem(v); setError(""); }}
              placeholder="I've been struggling with…"
              placeholderTextColor="#7d867d"
              multiline
              maxLength={3000}
              textAlignVertical="top"
              style={styles.input}
              accessibilityLabel="Describe what's going on"
            />
            <Text style={styles.counter}>{characterCount}/3000</Text>
            <Text style={styles.label}>OR START WITH A TOPIC</Text>
            <View style={styles.chips}>
              {topics.map((topic) => (
                <Pressable key={topic.label} onPress={() => { setProblem(topic.prompt); setError(""); }} style={({ pressed }) => [styles.chip, pressed && styles.pressed]}>
                  <Text style={styles.chipText}>{topic.label}</Text>
                </Pressable>
              ))}
            </View>
            {error ? <Text style={styles.error}>{error}</Text> : null}
            <Pressable onPress={explore} style={({ pressed }) => [styles.button, pressed && styles.pressed]} accessibilityRole="button">
              <Text style={styles.buttonText}>Explore biblical guidance  →</Text>
            </Pressable>
            <Text style={styles.privacy}>Privacy-first concept: your story stays on this device in this demo. Nothing is uploaded or saved by this starter app.</Text>
          </View>

          {guidance && (
            <View style={styles.card}>
              <Text style={styles.kicker}>A MOMENT TO REFLECT</Text>
              <Text style={styles.resultTitle}>You don't have to figure it all out at once.</Text>
              <View style={styles.answer}>
                <Text style={styles.answerTitle}>📖  What Scripture says</Text>
                <Text style={styles.answerText}>{guidance.scripture}</Text>
              </View>
              <View style={styles.answer}>
                <Text style={styles.answerTitle}>🌱  Putting it into practice</Text>
                <Text style={styles.answerText}>{guidance.practice}</Text>
              </View>
              <View style={styles.answer}>
                <Text style={styles.answerTitle}>🤍  A short prayer</Text>
                <Text style={styles.answerText}>{guidance.prayer}</Text>
              </View>
              <Pressable onPress={() => { setProblem(""); setGuidance(null); setError(""); }} style={styles.secondaryButton}>
                <Text style={styles.secondaryText}>Start a new reflection</Text>
              </Pressable>
            </View>
          )}

          <View style={styles.verseCard}>
            <Text style={styles.label}>TODAY'S REFLECTION</Text>
            <Text style={styles.verse}>“Come to me, all you who are weary and burdened, and I will give you rest.”</Text>
            <Text style={styles.reference}>MATTHEW 11:28</Text>
          </View>

          <View style={styles.adCard}>
            <Text style={styles.label}>ADVERTISEMENT SPACE</Text>
            <Text style={styles.muted}>Reserved for a future banner ad, subject to ad-network approval. No ad is served in this starter.</Text>
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerTitle}>A gentle reminder</Text>
            <Text style={styles.footerText}>This is a reflection aid, not a substitute for professional, pastoral, or emergency support. It does not claim to speak directly for Jesus. If you are in danger, seek immediate local help.</Text>
            <Text style={styles.footerText}>Sample guidance only. This starter does not use live AI, transmit your story, store personal data, or serve ads.</Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f7f5ef" },
  page: { padding: 18, paddingBottom: 36, gap: 16, maxWidth: 760, width: "100%", alignSelf: "center" },
  header: { flexDirection: "row", alignItems: "center", gap: 11, paddingVertical: 8 },
  logo: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#315b43", alignItems: "center", justifyContent: "center" },
  logoText: { color: "#fffdf8", fontSize: 22 },
  brand: { color: "#202b23", fontWeight: "800", fontSize: 17 },
  tagline: { color: "#607263", fontSize: 9, letterSpacing: 1.7, marginTop: 3, fontWeight: "700" },
  badge: { borderWidth: 1, borderColor: "#d5d9cf", borderRadius: 20, paddingHorizontal: 10, paddingVertical: 6 },
  badgeText: { color: "#607263", fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  hero: { paddingTop: 16, paddingBottom: 4 },
  kicker: { color: "#315b43", fontSize: 11, fontWeight: "800", letterSpacing: 1.8, textTransform: "uppercase" },
  title: { color: "#202b23", fontFamily: Platform.OS === "ios" ? "Georgia" : "serif", fontSize: 39, lineHeight: 43, marginTop: 12, marginBottom: 12 },
  intro: { color: "#69736a", fontSize: 15, lineHeight: 23 },
  card: { backgroundColor: "#fffdf8", borderColor: "#e3e4d9", borderWidth: 1, borderRadius: 22, padding: 19 },
  sectionTitle: { color: "#202b23", fontSize: 19, fontWeight: "800", marginBottom: 7 },
  muted: { color: "#69736a", fontSize: 13, lineHeight: 20 },
  input: { minHeight: 130, marginTop: 16, marginBottom: 4, borderWidth: 1, borderColor: "#dfe2d8", borderRadius: 14, backgroundColor: "#faf9f4", padding: 14, fontSize: 15, lineHeight: 22, color: "#202b23" },
  counter: { textAlign: "right", color: "#7d867d", fontSize: 10, marginBottom: 16 },
  label: { color: "#607263", fontSize: 10, fontWeight: "800", letterSpacing: 1.3, marginBottom: 10 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 18, marginTop: 2 },
  chip: { borderWidth: 1, borderColor: "#dfe2d8", borderRadius: 22, paddingHorizontal: 12, paddingVertical: 9, backgroundColor: "#fffdf8" },
  chipText: { color: "#526456", fontSize: 12, fontWeight: "600" },
  pressed: { opacity: 0.75 },
  button: { backgroundColor: "#315b43", padding: 15, borderRadius: 13, alignItems: "center" },
  buttonText: { color: "#fffdf8", fontWeight: "800", fontSize: 14 },
  privacy: { color: "#7a8378", fontSize: 11, lineHeight: 16, marginTop: 12 },
  error: { color: "#9b342a", fontSize: 12, marginBottom: 10 },
  resultTitle: { color: "#202b23", fontFamily: Platform.OS === "ios" ? "Georgia" : "serif", fontSize: 25, lineHeight: 31, marginTop: 9, marginBottom: 4 },
  answer: { borderTopWidth: 1, borderTopColor: "#e3e4d9", paddingTop: 15, marginTop: 12 },
  answerTitle: { color: "#202b23", fontSize: 14, fontWeight: "800", marginBottom: 8 },
  answerText: { color: "#59645b", fontSize: 14, lineHeight: 22 },
  secondaryButton: { borderWidth: 1, borderColor: "#d5d9cf", padding: 12, borderRadius: 12, alignItems: "center", marginTop: 18 },
  secondaryText: { color: "#315b43", fontWeight: "700", fontSize: 13 },
  verseCard: { backgroundColor: "#e9ede3", borderRadius: 19, padding: 19 },
  verse: { color: "#25352a", fontFamily: Platform.OS === "ios" ? "Georgia" : "serif", fontSize: 22, lineHeight: 31, marginBottom: 12 },
  reference: { color: "#315b43", fontSize: 11, fontWeight: "800", letterSpacing: 1.5 },
  adCard: { borderWidth: 1, borderStyle: "dashed", borderColor: "#cdd3c8", borderRadius: 16, padding: 16 },
  footer: { paddingHorizontal: 4, gap: 8 },
  footerTitle: { color: "#354338", fontWeight: "800", fontSize: 13 },
  footerText: { color: "#737d73", fontSize: 11, lineHeight: 17 },
});
