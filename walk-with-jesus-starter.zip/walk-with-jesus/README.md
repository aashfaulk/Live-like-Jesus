# Walk With Jesus — $0 starter app

This is a starter project for an iPhone/Android app built with Expo and React Native.

## What works now
- Mobile-first screens for iOS and Android
- Eight suggested life topics
- Sample Scripture-based guidance, practical next steps, and prayer
- Privacy-first demo: the story is processed locally in the app and is not uploaded or saved
- A placeholder for a future banner ad (no ad SDK is included)

## Important limitations
This is an early prototype, not a production-ready app. It does **not** include a live AI model, backend, analytics, accounts, saved history, or real ads. Guidance is selected from local sample responses, so it will not deeply understand every situation. Review all Bible quotations, references, pastoral language, accessibility, and safety handling before public release.

## Try it for free
1. Install Node.js on a computer from https://nodejs.org (free).
2. In this folder, run `npm install`.
3. Run `npx expo start`.
4. Install **Expo Go** on your iPhone or Android phone, then scan the QR code shown by Expo while your phone and computer are on the same Wi-Fi network.

Expo's free tooling can help you test on a real device. Native app-store publishing has separate requirements and may involve fees: Apple Developer Program membership is generally paid annually, and Google Play Console generally charges a one-time registration fee. Fees and policies can change, so check the official stores before planning a release.

## Zero-cost plan
1. Test this starter on real phones.
2. Improve the guidance library and add content reviewed by a trusted pastor/Bible scholar.
3. Keep personal stories off third-party AI services unless the privacy terms are suitable and users clearly consent.
4. Decide later whether to add a live AI service. Free tiers can have limits and data-use terms.
5. Add an ad SDK only after reviewing its privacy disclosures, consent requirements, and platform policies. Never target ads based on a user's spiritual struggles or sensitive story.
6. Before launch, add crisis/safety handling, a privacy policy, an appropriate Bible translation/licensing plan, tests, and production error handling.

## Project structure
- `App.js` — screens, local guidance examples, and styles
- `app.json` — Expo app metadata
- `package.json` — dependencies and commands
